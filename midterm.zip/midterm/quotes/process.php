<?php

if (isset($_POST["index"])){
    echo $_POST["index"];
}

