<?php
require 'auth.php';
session_start();
signout(); //CALLS FUNCTION IN AUTH.PHP