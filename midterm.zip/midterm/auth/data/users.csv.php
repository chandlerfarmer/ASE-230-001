<?php die() ?>
chandlerfarmer57@gmail.com;$2y$10$nhraEIflenQUgAInosK9v.2TxwNpqnEDaZlPaUqmsOgnJ62brE91K
farmerc4@mymail.nku.edu;$2y$10$2E0krCodAj8uFfWdE6NbluFuw5962wa2MMhQjmvTqI0QLwstdzMcS